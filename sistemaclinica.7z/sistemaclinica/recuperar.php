<?php


require_once('conexao.php');
require_once('config.php');



?>


<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Easy Clínicas Login</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-1">



	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="login.css">

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>

	
<body>

	<div class="login-form">
		<form method="post">
			<div class="logo">
				<img src="img/ec1.png" alt="Easy Clínicas">
			</div>
			<h2 class="text-center" id="testeh2">Recuperar senha</h2>
			<div class="form-group">
				<input class="form-control" type="email" name="txtEmail" placeholder="Insira seu email" required>
			</div>
			
			<div class="d-grid gap-2">
			  	<button class="btn btn-primary" type="submit" name="recuperar-senha">Recuperar</button>
			  
			</div>

			<div class="clearfix">
				
				</label>
				<a href="index.php" class="pull-right">Voltar</a>

			</div>

		</form>
		
	</div>


</body>


</html>


<?php

if(isset($_POST['recuperar-senha'])){

	$email_usuario = $_POST['txtEmail'];

	$res = $pdo->prepare("SELECT * FROM usuarios WHERE usuario = :u");
	$res->bindValue($email_usuario, ":u");
	$res->execute();

	$dados = $res->fetchAll(PDO::FETCH_ASSOC);

	$linhas = count($dados); 

	if($linhas > 0){

		$nome_usu = $dados[0]['nome'];
		$senha_usu = $dados[0]['senha'];
		$nivel_usu = $dados[0]['nivel'];

	}else{

		echo "<script language = 'javascript'> window.alert('Email não cadastrado'); </script>";

	}

	//codigo de envio de email


	$to = $email_usuario;
			$subject = 'Recuperação de Senha SysMedical';

			$message = "

			Olá $nome_usu!! 
			<br><br> Sua senha é <b>$senha_usu </b>

			<br><br> Ir Para o Sistema -> <a href='$url_site' target='_blank'> Clique Aqui </a>
			";

			$remetente = $email_adm;
			$headers = 'MIME-Version: 1.0' . "\r\n";
			$headers .= 'Content-type: text/html; charset=utf-8;' . "\r\n";
			$headers .= "From: " .$remetente;
			mail($to, $subject, $message, $headers);


			echo "<script language='javascript'>window.alert('Sua senha foi enviada no seu email, verifique no spam ou lixo eletrônico!!'); </script>";

			echo "<script language='javascript'>window.location='index.php'; </script>";
}




?>
