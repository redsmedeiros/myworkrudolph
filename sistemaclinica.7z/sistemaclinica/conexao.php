<?php

try {

	date_default_timezone_set('America/Sao_Paulo');

	$pdo = new PDO("mysql:dbname=easy2; host=localhost", "root", "");
	
} catch (Exception $e) {

	echo "Erro de conexão com banco de dados ".$e;
	
}








?>