<?php

$opcao1 = 3;
$opcao2 = 5;
$opcao3 = 10;

//variavel para hospedagem
$url_sistema = 'http://localhost/sistemaclinica';

$email_adm = 'redsmedeiros@gmail.com';




?>