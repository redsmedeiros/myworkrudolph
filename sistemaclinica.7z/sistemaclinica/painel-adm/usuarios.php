<?php

$pagina = 'usuarios';




?>



<div class="row ml-1">
	<div class="col-md-12">

		<a data-toggle="modal" data-target="#modal"  id="btn-medico"></a>

		<a href="index.php?acao=usuarios&funcao=novo" type="button" class="btn btn-secondary" id="btn-medico">Novo usuário</a>
	</div>
	

</div>

<div class="row mt-4">
	<div class="col-md-6 col-sm-12">

		<div class="float-left">
			
			
			<form method="post">
				<select onChange="submit();" class="form-control-sm" id="exampleFormControlSelect1" name="itens-pagina">
					
					<option value="2">2</option>
					<option value="4">4</option>
					<option value="6">6</option>
					<option value="6">10</option>
					<option value="6">20</option>

				</select>
			</form>
			


		</div>
		
	</div>
	

	<div class="col-md-6 col-sm-12">

		<div class="float-right mr-4">
			<form class="form-inline my-2 my-lg-0">
				<input class="form-control form-control-sm mr-sm-2" type="search" placeholder="Nome" aria-label="Search" name="txtbuscar">
				<button class="btn btn-outline-secondary btn-sm my-2 my-sm-0" type="submit" name="<?php echo $pagina; ?>">Buscar</button>
			</form>
		</div>

		
	</div>

	


</div>

<table class="table table-sm mt-3">
	<thead class="thead-light">
		<tr>
			<th scope="col">Nome</th>
			<th scope="col">Usuários</th>
			<th scope="col">Senha</th>
			<th scope="col">Nível</th>
			<th scope="col">Ações</th>
		</tr>
	</thead>
	<tbody>

		<?php

		//definir o numero de iten por pagina

		if(isset($_POST['itens-pagina'])){

			$itens_por_pagina = $_POST['itens-pagina'];

		}else{

			$itens_por_pagina = 3;
		}

		//pegar a pagina atual

		$pagina_pag = intval(@$_GET['pagina']);	
		$limite = $pagina_pag * $itens_por_pagina;

		//caminha da paginação

		$caminho_pag = 'index.php?acao='.$pagina.'&'; 

		

		

		if(isset($_GET[$item4]) and $_GET['txtbuscar'] != ''){

			$nome_buscar = '%'.$_GET['txtbuscar'].'%';

			$res = $pdo->prepare("SELECT * FROM usuarios WHERE nome LIKE :nome ORDER BY nome ASC LIMIT $limite, $itens_por_pagina");
			$res->bindValue(":nome", $nome_buscar);
			$res->execute();


		} else {

			$res = $pdo->query("SELECT * FROM usuarios ORDER BY nome ASC LIMIT $limite, $itens_por_pagina");
		}

		

		$dados = $res->fetchAll(PDO::FETCH_ASSOC);


		//total de registro para paginação
		$res_todos = $pdo->query("SELECT * FROM usuarios");
		$dados_total = $res_todos->fetchAll(PDO::FETCH_ASSOC);
		$num_total = count($dados_total);

		//definir total de paginas
		$num_paginas = ceil($num_total/$itens_por_pagina);
		

		for($i = 0; $i < count($dados); $i++){

			foreach ($dados[$i] as $k => $v) {
            	
            	
			}

			$id = $dados[$i]['id'];
			$nome = $dados[$i]['nome'];
			$usuario = $dados[$i]['usuario'];
			$senha = $dados[$i]['senha'];
			$nivel = $dados[$i]['nivel'];


		


		?>


		<tr>

			<td> <?php echo $nome ?></td>
			<td> <?php echo $usuario ?></td>
			<td> <?php echo $senha ?></td>
			<td> <?php echo $nivel ?></td>
			<td>
				
				<a href="index.php?acao=<?php echo $pagina; ?>&funcao=editar&id=<?php echo $id ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
					<path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
					<path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
				</svg>

				</a>

				<a href="index.php?acao=<?php echo $pagina; ?>&funcao=excluir&id=<?php echo $id ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
					<path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
					<path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
				</svg>

				</a>
			</td>
		</tr>

	<?php } ?>

	</tbody>


</table>

<nav aria-label="Page navigation example">
          <ul class="pagination">
            <li class="page-item">
              <a class="btn btn-outline-dark mr-1" href="<?php echo $caminho_pag; ?>pagina=0" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>
                <span class="sr-only">Previous</span>
              </a>
            </li>
            <?php 
            for($i=0;$i<$num_paginas;$i++){
            $estilo = "";
            if($pagina_pag == $i)
              $estilo = "active";
            ?>
             <li class="page-item"><a class="btn btn-outline-dark mr-1 <?php echo $estilo; ?>" href="<?php echo $caminho_pag; ?>pagina=<?php echo $i; ?>"><?php echo $i+1; ?></a></li>
          <?php } ?>
            
            <li class="page-item">
              <a class="btn btn-outline-dark" href="<?php echo $caminho_pag; ?>pagina=<?php echo $num_paginas-1; ?>" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="sr-only">Next</span>
              </a>
            </li>
          </ul>
</nav>




<!-- Modal -->
<div class="modal fade" id="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">

					<?php if(@$_GET['funcao'] == 'editar'){

						$nome_botao = "Editar";

						$id_usuario = $_GET['id'];

						//BUSCAR DADOS DO REGISTRO A SER EDITADO
						$res = $pdo->query("select * from usuarios where id = '$id_usuario'");
						$dados = $res->fetchAll(PDO::FETCH_ASSOC);
						$nome_usuario = $dados[0]['nome'];
						$email_usuario = $dados[0]['usuario'];
						$senha_usuario = $dados[0]['senha'];
						$email_usuario_rec = $dados[0]['usuario'];

						echo "Editar usuário";

					}else{

						$nome_botao = "Salvar";
						echo "Cadastro de usuário";
					} 

					?>

					</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<form method="post">

					
						
						<div class="form-group">
							<label for="exampleFormControlInput1">Nome</label>
							<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Insira o nome" name="nome" value="<?php echo @$nome_usuario ?>">
						</div>

						

						<div class="form-group">
							<label for="exampleFormControlInput1">Email</label>
							<input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Insira o email" name="usuario" value="<?php echo @$email_usuario ?>">
						</div>

						<div class="form-group">
							<label for="exampleFormControlInput1">Senha</label>
							<input type="text" class="form-control" id="senha" placeholder="Insira a senha" name="senha" value="<?php echo @$senha_usuario ?>">
						</div>
						



					
				



			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
				
					<button type="submit" name="<?php echo $nome_botao ?>" class="btn btn-primary"><?php echo $nome_botao ?></button>
				</form>
				
			</div>
		</div>
	</div>
</div>



<!--Codigo botao novo-->

<?php

if(@$_GET['funcao'] == 'novo'){	 



?>

<script>$('#btn-medico').click();</script>

<?php } ?>








<?php

//botao salvar

if (isset($_POST['Salvar'])) {

	$nome = $_POST['nome'];
	$usuario = $_POST['usuario'];
	$senha = $_POST['senha'];


	//verificar se usuário já esta cadastrado

	$consulta = $pdo->query("SELECT * FROM usuarios WHERE usuario = '$usuario' ");
	$dados_consulta = $consulta->fetchAll(PDO::FETCH_ASSOC);

	$linhasconsulta = count($dados_consulta);

	if( $linhasconsulta == 0){

	$res = $pdo->prepare("INSERT INTO usuarios (nome, usuario, senha, nivel) VALUES (:n, :u, :s, :ni)");
			$res->bindValue(":n", $nome);
			$res->bindValue(":u", $usuario);
			$res->bindValue(":s", $senha);
			$res->bindValue(":ni", 'admin');
			$res->execute();

	echo "<script language='javascript'>window.location='index.php?acao=$pagina'; </script>";		
			

	} else {

		
		echo "<script language='javascript'>window.location='index.php?acao=$pagina'; </script>";
	}
	
}




?>


<?php

//botao editar

if(@$_GET['funcao'] == 'editar'){
	



?>	
	


<script>$('#btn-medico').click();</script>


<?php 
	if(isset($_POST['Editar'])){
		$nome = $_POST['nome'];
		$usuario = $_POST['usuario'];
		$senha = $_POST['senha'];
		

	//VERIFICAR SE O USUÁRIO JÁ ESTÁ CADASTRADO SOMENTE SE FOR TROCADO O USUÁRIO
		if($email_usuario_rec != $usuario){
			$res_c = $pdo->query("select * from usuarios where usuario = '$usuario'");
			$dados_c = $res_c->fetchAll(PDO::FETCH_ASSOC);
			$linhas = count($dados_c);
			if($linhas != 0){

				echo "<script language='javascript'>window.alert('Este usuário já está cadastrado!!'); </script>";
				exit();
			}
		}


		$res = $pdo->prepare("UPDATE usuarios set nome = :nome, usuario = :usuario, senha = :senha where id = :id ");

		$res->bindValue(":nome", $nome);
		$res->bindValue(":usuario", $usuario);
		$res->bindValue(":senha", $senha);
		$res->bindValue(":id", $id_usuario);
		

		$res->execute();

		
		echo "<script language='javascript'>window.location='index.php?acao=$pagina'; </script>";





	}

	?>

<?php } ?>

<?php 

//botão excluir

if ( @$_GET['funcao'] == 'excluir') {

	$id_usuario = $_GET['id'];

	$res = $pdo->query("DELETE FROM usuarios WHERE id = '$id_usuario' ");

	

	echo "<script language='javascript'>window.location='index.php?acao=$pagina'; </script>";


}

?>



