<div class="row ml-1">
	<div class="col-md-12">
		<button data-toggle="modal" data-target="#modal" type="button" class="btn btn-secondary" id="btn-medico">Novo médico</button>
	</div>
	

</div>

<div class="row mt-4">
	<div class="col-md-6 col-sm-12">

		<div class="float-left">
			
			<label class="registro" for="exampleFormControlSelect1">Registros</label>
			<select class="form-control-sm" id="exampleFormControlSelect1">
				<option>10</option>
				<option>25</option>
				<option>50</option>

			</select>
			


		</div>
		
	</div>
	

	<div class="col-md-6 col-sm-12">

		<div class="float-right mr-4">
			<form class="form-inline my-2 my-lg-0">
				<input class="form-control form-control-sm mr-sm-2" type="search" placeholder="Nome ou CRM" aria-label="Search" name="txtbuscar">
				<button class="btn btn-outline-secondary btn-sm my-2 my-sm-0" type="submit" name="<?php echo $item2; ?>">Buscar</button>
			</form>
		</div>

		
	</div>

	


</div>

<table class="table table-sm mt-3">
	<thead class="thead-light">
		<tr>
			<th scope="col">Nome</th>
			<th scope="col">Especialidade</th>
			<th scope="col">CRM</th>
			<th scope="col">Telefone</th>
			<th scope="col">Ações</th>
		</tr>
	</thead>
	<tbody>
		<tr>

			<td>Sabrina Daniela</td>
			<td>Ortopedia</td>
			<td>MG 123456</td>
			<td>31 9 6556-4231</td>
			<td>
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
					<path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
					<path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
				</svg>

				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
					<path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
					<path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
				</svg>
			</td>
		</tr>

	</tbody>
</table>




<!-- Modal -->
<div class="modal fade" id="modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">Cadastros de médicos</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">

				<form>

					<div class="row">
						<div class="col-md-6 col-sm-12">
							<div class="form-group">
								<label for="exampleFormControlInput1">Nome</label>
								<input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Insira o nome" name="nome">
							</div>

						</div>
						<div class="col-md-6 col-sm-12">
							<div class="form-group">
							<label for="exampleFormControlSelect1">Especialidade</label>
							<select class="form-control" id="exampleFormControlSelect1" name="especialidade">
								<option>1</option>

							</select>
						</div>

					</div>

				</div>


				<div class="row">
					<div class="col-md-4 col-sm-12">
						<div class="form-group">
							<label for="exampleFormControlInput1">CPF</label>
							<input type="text" class="form-control" id="cpf" placeholder="Insira o CPF" name="cpf">
						</div>




					</div>

					<div class="col-md-4 col-sm-12">
						<div class="form-group">
							<label for="exampleFormControlInput1">Telefone</label>
							<input type="text" class="form-control" id="telefone" placeholder="Insira o telefone" name="telefone">
						</div>


						
					</div>

					<div class="col-md-4 col-sm-12">
						<div class="form-group">
							<label for="exampleFormControlInput1">Email</label>
							<input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Insira o email">
						</div>


						
					</div>
					


				</div>

					

					

					

					
					

					





					<div class="form-group">
						<label for="exampleFormControlInput1">Email address</label>
						<input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
					</div>

					
				</form>



			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
				<form method="post">
					<button type="submit" name="btn-salvar" class="btn btn-primary">Salvar</button>
				</form>
				
			</div>
		</div>
	</div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>


<script type="text/javascript">
	
	$(document).ready(function(){

		$('#telefone').mask('(00) 00000-0000')
		$('#cpf').mask('000.000.000-00')


	});
	

</script>
