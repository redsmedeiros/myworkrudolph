<?php

require_once("../conexao.php");

@session_start();

if(!isset($_SESSION['nome_usuario']) || $_SESSION['nivel_usuario'] != 'admin'){

	header("location:../index.php");

}

	$notificacoes = 1;

//Variaveis

$item1 = "home";
$item2 = "medicos";
$item3 = "funcionarios";
$item4 = "usuarios";
$item5 = "notificacoes";

//verificar se o menu está ativo

if(@($_GET['acao']) == $item1) { 
							
	$item1ativo = "active";
						
} elseif (@($_GET['acao']) == $item2 or isset($_GET[$item2])) {

	$item2ativo = "active";
						
} elseif (@($_GET['acao']) == $item3) {

	$item3ativo = "active";

} elseif (@($_GET['acao']) == $item4) {

	$item4ativo = "active";

} elseif (@($_GET['acao']) == $item5) {

	$item5ativo = "active";

} else {

	$item1ativo = "active";
}




?>




<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Painel administrativo</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale-1">



	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="painel.css">

	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>

	
<body>
	
	<nav class="navbar navbar-light bg-light">
		<div class="col-md-12">
				
				<img class="float-left" src="../img/e2.png">
				
				<li class="float-end nav-item dropdown">
						
						<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							Gerenciamento - <?php 

							
								
								echo $_SESSION['nome_usuario']; 

							

							?>
							
						</a>
						
						<div class="dropdown-menu" aria-labelledby="navbarDropdown">
							
							<a class="dropdown-item" id="testea" href="../logout.php">Sair</a>

						</div>
					</li>
			
			
		</div>
	</nav>

	<div class="container-fluid mt-4">
		<div class="row">
			<div class="col-md-3 col-sm-12">
				<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
					
					<a class="nav-link <?php echo $item1ativo ?> " id="v-pills-home-tab" href="index.php?acao=<?php echo $item1 ?>" role="tab" aria-controls="v-pills-home" aria-selected="true"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-door" viewBox="0 0 16 16">
  <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146zM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4H2.5z"/>
</svg> Home</a>
					
					<a class="nav-link <?php echo $item2ativo ?>" id="link-medicos" href="index.php?acao=<?php echo $item2 ?>" role="tab" aria-controls="v-pills-profile" aria-selected="false"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
  <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
</svg> Cadastro médico</a>
					
					<a class="nav-link <?php echo $item3ativo ?>" id="v-pills-messages-tab"  href="index.php?acao=<?php echo $item3 ?>" role="tab" aria-controls="v-pills-messages" aria-selected="false"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
  <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
</svg> Cadastro administrativo</a>

					<a class="nav-link <?php echo $item4ativo ?>" id="link-medicos" href="index.php?acao=<?php echo $item4 ?>" role="tab" aria-controls="v-pills-profile" aria-selected="false"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
  <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
</svg> Cadastro usuários</a>


					<?php if($notificacoes >0){ ?>
					
					<a class="nav-link <?php echo $item5ativo ?>" id="v-pills-messages-tab"  href="index.php?acao=<?php echo $item5 ?>" role="tab" aria-controls="v-pills-messages" aria-selected="false"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-exclamation" viewBox="0 0 16 16">
  <path d="M2 2a2 2 0 0 0-2 2v8.01A2 2 0 0 0 2 14h5.5a.5.5 0 0 0 0-1H2a1 1 0 0 1-.966-.741l5.64-3.471L8 9.583l7-4.2V8.5a.5.5 0 0 0 1 0V4a2 2 0 0 0-2-2H2Zm3.708 6.208L1 11.105V5.383l4.708 2.825ZM1 4.217V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v.217l-7 4.2-7-4.2Z"/>
  <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1.5a.5.5 0 0 1-1 0V11a.5.5 0 0 1 1 0Zm0 3a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Z"/>
</svg> Notificações <span class="badge badge-light"><?php echo $notificacoes;?> <?php } ?></span>
				</a>
				</div>
			</div>
			
			<div class="col-md-9 col-sm-12">
				<div class="tab-content" id="v-pills-tabContent">
					
					<div class="tab-pane fade show active"  role="tabpanel" >
						
						<?php if(@($_GET['acao']) == $item1) { 
							
							include_once($item1.".php");
						
						} elseif (@($_GET['acao']) == $item2 or isset($_GET[$item2])) {

							include_once($item2.".php");
						
						} elseif (@($_GET['acao']) == $item3) {

							include_once($item3.".php");

						} elseif (@($_GET['acao']) == $item4 or isset($_GET[$item4])) {

							include_once($item4.".php");

						} elseif (@($_GET['acao']) == $item5) {

							include_once($item5.".php");

						} else {

							include_once($item1.".php");
						}

						?>
					
					</div>
					
							
					
					
						
				</div>
			</div>
		</div>
		
	</div>
	
	


</body>
</html>

