import pygame
from laser import Laser

#criar uma classe player passando o parametro que será herdado
class Player(pygame.sprite.Sprite):
    def __init__(self,pos, constraint, speed):
        #chamar o metodo construtor herdado
        super().__init__()
        #importar a imagem do jogo
        self.image = pygame.image.load('png/player.png').convert_alpha()
        #obter o retangulo da imagem e posicionar
        self.rect = self.image.get_rect(midbottom = pos)
        #variavel de controle da velocidade de movimento
        self.speed = speed
        #atribuir o valor de constraint para o eixo X
        self.max_constraint_x = constraint
        #variavel que prepara o tiro
        self.ready = True
        #variavel para indicar quando atirar de 0 ate 600 milisegundos
        self.laser_time = 0
        self.laser_cooldown = 600

        self.lasers = pygame.sprite.Group()
        self.laser_sound = pygame.mixer.Sound('png/audio_laser.wav')
        self.laser_sound.set_volume(0.5)

    #função para obter a entrada de teclado
    def get_input_player(self):
        #variavel para obter a tecla pressionada
        keys = pygame.key.get_pressed()
        #chevar a variavel pressionada e atualizar posição no eixo X
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        elif keys[pygame.K_LEFT]:
            self.rect.x -= self.speed

        #verificação para o tiro do jogador, jogador precisar estar com o laser pronto
        if keys[pygame.K_SPACE] and self.ready:
            self.shoot_laser()
            self.ready = False
            self.laser_time = pygame.time.get_ticks()
            self.laser_sound.play()

    #metodo para recarregar o laser
    def recharge(self):
        #se for falso
        if not self.ready:
            current_time = pygame.time.get_ticks()
            if current_time - self.laser_time >= self.laser_cooldown:
                self.ready = True



    #metodo de limitação da tela
    def constraint(self):
        #se o player chegar a posição 0 do eixo X
        if self.rect.left <= 0:
            self.rect.left = 0
        #se o player atingir o valor maximo para o eixo x
        if self.rect.right >= self.max_constraint_x:
            self.rect.right = self.max_constraint_x

    #toda vez que a função de tiro for disparada é criado um sprite e passada a posição
    def shoot_laser(self):
        #passar a posição do laser
        self.lasers.add(Laser(self.rect.center, -8, self.rect.bottom))

    #metodo de atualização do player
    def update(self):
        #chamar o metodo de obtenção das entradas para atualizar a cada frame
        self.get_input_player()
        #chamar o metodo de restrição do eixo a cada frame
        self.constraint()
        #chamar o metodo de carregar
        self.recharge()
        #chamar o metodo do obj laser de atualização
        self.lasers.update()

