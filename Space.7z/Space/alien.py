import pygame

#criar a classe de aliens passando como parametro o construtor herdado
class Alien(pygame.sprite.Sprite):
    #criar o construtor da classe
    def __init__(self, color,x,y):
        #chamar o construtor herdado
        super().__init__()
        #criar o caminho do arquivo de imagem concatenando com a cor
        file_path = 'png/' + color +'.png'
        #criar a imagem e o retangulo da imagem
        self.image = pygame.image.load(file_path).convert_alpha()
        #passar para o retangulo a imagem criada
        self.rect = self.image.get_rect(topleft = (x,y))

        if color == 'red': self.value = 100
        elif color == 'green': self.value = 200
        else: self.value = 300

    #metodo para atualizar a posição
    def update(self, direction):
        self.rect.x += direction

class Extra(pygame.sprite.Sprite):
    #cronstrutor do alien extra
    def __init__(self, side, screen_width):
        #construtor herdado
        super().__init__()
        self.image = pygame.image.load('png/extra.png').convert_alpha()


        if side == 'right':
            x = screen_width + 50
            self.speed = -3
        else:
            x = -50
            self.speed = 3

        self.rect = self.image.get_rect(topleft = (x,80))

    def update(self):
        self.rect.x += self.speed

