import pygame, sys
from player import Player
import obstacle
from alien import Alien, Extra
from random import choice, randint
from laser import Laser

#classe principal
class Game:
    #metodo construtor para colocar as sprites
    def __init__(self):
        #player setup
        player_sprite = Player((screen_width/2, screen_heigth), screen_width, 5)
        self.player = pygame.sprite.GroupSingle(player_sprite)

        #pontuação e vidas
        self.lives = 3
        self.live_surf = pygame.image.load('png/player.png').convert_alpha()
        self.live_x_start_pos = screen_width - (self.live_surf.get_size()[0] * 2 +20)
        self.score = 0
        self.font = pygame.font.Font('png/Pixeled.ttf',20)


        #obstacles setup

        #criar a forma do obstacle
        self.shape = obstacle.shape
        #setar o tamanho do obstaculo
        self.block_size = 6
        self.blocks = pygame.sprite.Group()
        self.obstacle_amount = 4
        self.obstacles_x_positions = [num * (screen_width / self.obstacle_amount) for num in range(self.obstacle_amount)]
        self.create_multiple_obstacles(*self.obstacles_x_positions, x_start = screen_width /15, y_start = 480)

        #setup para os aliens

        self.aliens = pygame.sprite.Group()
        self.alien_lasers = pygame.sprite.Group()

        #função para posicionar os aliens
        self.alien_setup(rows = 6, cols = 8)
        #atributo de velocidade dos aliens no eixo x
        self.alien_direction = 1

        #extra setup
        self.extra = pygame.sprite.GroupSingle()
        self.extra_spawn_time = randint(40,80)

        #audio setup
        music = pygame.mixer.Sound('png/music.wav')
        music.set_volume(0.2)
        music.play(loops = -1)
        self.laser_sound = pygame.mixer.Sound('png/audio_laser.wav')
        self.laser_sound.set_volume(0.5)
        self.explosion_sound = pygame.mixer.Sound('png/audio_explosion.wav')
        self.explosion_sound.set_volume(0.3)



    #criar a função para os obstacles
    def create_obstacle(self, x_start, y_start,offset_x):
        for row_index, row in enumerate(self.shape):
            for col_index, col in enumerate(row):
                if col == 'x':
                    x = x_start +col_index * self.block_size + offset_x
                    y = y_start + row_index * self.block_size
                    block = obstacle.Block(self.block_size,(241,79,80),x,y)
                    self.blocks.add(block)

    #criar a função para multiplos obstaculos
    def create_multiple_obstacles(self, *offset, x_start, y_start):
        for offset_x in offset:
            self.create_obstacle(x_start, y_start, offset_x)

    #função de setup dos aliens
    def alien_setup(self, rows, cols, x_distance = 60, y_distance = 48, x_offset = 70, y_offset = 100):
        #função range traz um conjunto de numeros de x ate y
        for row_index, row in enumerate(range(rows)):
            for col_index, col in enumerate(range(cols)):
                x = col_index * x_distance + x_offset
                y = row_index * y_distance + y_offset
                if row_index == 0:
                    #criar o objeto de aliens
                    alien_sprite = Alien('yellow',x,y)
                elif 1 <= row_index <= 2:
                    alien_sprite = Alien('green', x, y)
                else:
                    alien_sprite = Alien('red', x, y)

                self.aliens.add(alien_sprite)

    #verificar a posição dos aliens na tela e mudar a direção no eixo x
    def alien_position_checker(self):
        #pegar todos os aliens
        all_aliens = self.aliens.sprites()
        #iterar os aliens
        for alien in all_aliens:
            if alien.rect.right >= screen_width:
                self.alien_direction = -1
                self.alien_move_down(2)
            elif alien.rect.left <= 0:
                self.alien_direction = 1
                self.alien_move_down(2)

    #metodo para baixar em pixels os aliens
    def alien_move_down(self, distance):
        if self.aliens:
            for alien in self.aliens.sprites():
                alien.rect.y += distance

    #metodo para o tiro dos aliens
    def alien_shoot(self):
        if self.aliens.sprites():
            #selecionar um alien aleatorio
            random_alien = choice(self.aliens.sprites())
            laser_sprite = Laser(random_alien.rect.center,6,screen_heigth)
            self.alien_lasers.add(laser_sprite)
            self.laser_sound.play()

    #metodo para adicionar o alien extra
    def extra_alien_timer(self):
        self.extra_spawn_time -= 1
        if self.extra_spawn_time <= 0:
            self.extra.add(Extra(choice(['right','left']),screen_width))
            self.extra_spawn_time = randint(400, 800)

    def collision_checks(self):
        #player laser
        if self.player.sprite.lasers:
            for laser in self.player.sprite.lasers:
                #obstacle collissions
                if pygame.sprite.spritecollide(laser,self.blocks,True):
                    laser.kill()

                #alien colissions
                aliens_hit = pygame.sprite.spritecollide(laser,self.aliens,True)
                if aliens_hit:
                    for alien in aliens_hit:
                        self.score += alien.value
                    laser.kill()
                    self.explosion_sound.play()


                #extra collision
                if pygame.sprite.spritecollide(laser,self.extra,True):
                    laser.kill()
                    self.score += 500

        #alien laser
        if self.alien_lasers:
            for laser in self.alien_lasers:
                # obstacle collissions
                if pygame.sprite.spritecollide(laser, self.blocks, True):
                    laser.kill()

                if pygame.sprite.spritecollide(laser, self.player, False):
                    laser.kill()
                    self.lives -= 1
                    if self.lives <= 0:
                        pygame.quit()
                        sys.exit()

        #aliens
        if self.aliens:
            for alien in self.aliens:
                pygame.sprite.spritecollide(alien, self.blocks, True)

                if pygame.sprite.spritecollide(alien, self.player, False):
                    pygame.quit()
                    sys.exit()

    #metodo para as vidas
    def display_lives(self):
        for live in range(self.lives - 1):
            x = self.live_x_start_pos + (live * (self.live_surf.get_size()[0] + 10))
            screen.blit(self.live_surf,(x,8))

    #metodo do placar
    def display_score(self):
        score_surf = self.font.render(f'score: {self.score}', False, 'white')
        score_rect = score_surf.get_rect(topleft = (10,-10))
        screen.blit(score_surf,score_rect)

    #mensagem de vitoria
    def victory_message(self):
        #se não tiver mais aliens no grupo de aliens
        if not self.aliens.sprites():
            victory_surf = self.font.render('Você venceu!', False, 'white')
            victory_rect = victory_surf.get_rect(center = (screen_width / 2, screen_heigth / 2))
            screen.blit(victory_surf, victory_rect)

    #para atualizar e desenhar todos os sprites
    def run(self):

        #chamar o metodo get do objeto player de atualização
        self.player.update()
        #metodo de aliens para atualizar as posições
        self.aliens.update(self.alien_direction)
        self.alien_lasers.update()
        self.extra_alien_timer()
        self.extra.update()
        self.collision_checks()
        self.display_lives()
        #chamar o metodo checador de direção
        self.alien_position_checker()
        # desenhar os lasers
        self.player.sprite.lasers.draw(screen)
        #chamar o metodo de desenhar na tela do objeto player
        self.player.draw(screen)
        #chamar o metodo que desenha os blocos
        self.blocks.draw(screen)
        self.display_score()
        #chamar o metodo que desenha os aliens na tela
        self.aliens.draw(screen)
        self.alien_lasers.draw(screen)
        self.extra.draw(screen)
        self.victory_message()


#função de prevenção
if __name__ == '__main__':
#chamar função construtora do pygame
    pygame.init()
#definir variaveis de tela
    screen_width = 600
    screen_heigth = 600
#criar a variavel da tela
    screen = pygame.display.set_mode((screen_width,screen_heigth))
#criar o relogio para chamar frames
    clock = pygame.time.Clock()
#instanciar o objeto de game
    game = Game()
#timer para controlar os tiros dos aliens
    ALIENLASER = pygame.USEREVENT + 1
    pygame.time.set_timer(ALIENLASER,800)
#criar o loop principal
    while True:
    #capturar os eventos de sáida com o iterator
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == ALIENLASER:
                game.alien_shoot()
    #preencher cor da tela
        screen.fill((30,30,30))
    #chamar o método run de game
        game.run()

    #chamar função de atualização do frame
        pygame.display.flip()
    #passar a velocidade de atualização com o relogio
        clock.tick(60)
