import pygame

#criar a classe e passar a classe pai como parametro
class Laser(pygame.sprite.Sprite):
    def __init__(self, pos, speed,screen_height):
        super().__init__()

        #criar os atributos para imagem e retangulo
        self.image = pygame.Surface((4,20))
        self.image.fill('white')
        self.rect = self.image.get_rect(center = pos)
        self.speed = speed
        self.height_y_constraint = screen_height

    #função que destroi os lasers
    def destroy(self):
        if self.rect.y <= -50 or self.rect.y >= self.height_y_constraint + 50:
            self.kill()

    #criar a função de update
    def update(self):
        #a cada atualização a função irá atualizar a posição y
        self.rect.y += self.speed
        #chamar o metodo de destruir
        self.destroy()